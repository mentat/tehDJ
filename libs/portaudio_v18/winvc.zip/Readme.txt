Visual C++ 6.0 Workspace & makefiles for PortAudio (Static Libraries).
2 configurations, one using DirectSound (DS) and one using WMME.
Libraries are output to the Lib folder.
